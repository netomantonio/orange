package capitulo1;

public class QuinzeOuVintePorcento implements RegraDeCalculo{

	@Override
	public double calcula(Funcionario funcionario) {
		return 0;
	}

}
