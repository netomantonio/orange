package capitulo1;

public class CalculadoraDeSalario {

	public double calcula(Funcionario funcionario){
		return funcionario.calcularSalario();
	}

}