package capitulo1;

public interface RegraDeCalculo {
	public double calcula(Funcionario funcionario);
}
