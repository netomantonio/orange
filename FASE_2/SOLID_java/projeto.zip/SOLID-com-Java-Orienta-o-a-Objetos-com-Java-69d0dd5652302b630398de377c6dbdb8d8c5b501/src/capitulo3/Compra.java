package capitulo3;

public class Compra {
	private double valor;
	private String cidade;
	public double getValor() {
		return valor;
	}
	public String getCidade() {
		return cidade;
	}
	
	
}
