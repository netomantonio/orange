package capitulo3;

public interface TabelaDePreco {
	double descontoPara(double valor);
}
