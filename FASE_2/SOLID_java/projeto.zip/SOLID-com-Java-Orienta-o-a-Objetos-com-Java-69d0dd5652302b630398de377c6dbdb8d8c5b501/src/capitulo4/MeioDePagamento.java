package capitulo4;

public enum MeioDePagamento {

    BOLETO,
    CARTAO
}
