package br.com.alura.spring.data.orm;

public interface FuncionarioProjecao {
	Integer getId();
	String getNome();
	Double getSalario();
}
